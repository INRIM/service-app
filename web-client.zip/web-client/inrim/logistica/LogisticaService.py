# Copyright INRIM (https://www.inrim.eu)
# See LICENSE file for full licensing details.
import json
import os
import sys
import logging
from datetime import datetime, timedelta
from inrim.label_printer.PrinterService import PrinterService
from core.ProcessService import ProcessService


import logging

logger = logging.getLogger(__name__)


class LogisticaService(PrinterService):

    @classmethod
    def create(cls, gateway, remote_data):
        self = LogisticaService()
        self.init(gateway, remote_data)
        return self

    async def update_tasks(self, task_name, caledar_data, status={"status": "done"}):
        self.taskNames = ['run_sync_ugov_order']
        self.task_models = ["camunda_process"]
        exec_status = status.copy()
        if caledar_data and caledar_data.get("status", "error") == "success":
            calendar = caledar_data['calendar']
            task = caledar_data['task']
            if task['model'] in self.task_models:
                logger.info(task_name)
                exec_status = await getattr(
                    self, f"handle_{task['model']}")(task_name, task.copy(), calendar.copy())
        response = await super().update_tasks(task_name, caledar_data, exec_status.copy())
        return response

    async def handle_camunda_process(self, task_name, task, calendar):
        logger.info(f" {task['model']} -> {calendar.get('task_record_name')}")

        process_service = ProcessService.new(
            content_service=self, process_model=task['model'],
            process_name=calendar.get('task_record_name')
        )

        await process_service.start(update_data=False)
        logger.info(f" Background Process start {process_service.process['instance_id']}")
        updates = []
        return {"status": "done", "updates": updates}.copy()
