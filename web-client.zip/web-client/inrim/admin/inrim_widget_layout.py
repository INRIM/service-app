import os
import sys

import logging
import ujson
from core.main.widgets_layout import LayoutWidgetBase

logger = logging.getLogger(__name__)


class LayoutWidgeInrim(LayoutWidgetBase):

    @classmethod
    def create(cls, **kwargs):
        self = LayoutWidgeInrim()
        self.init(**kwargs)
        return self

    def prepare_render(self):
        template, values = super().prepare_render()
        values['identity'] = self.session.get(
            "user_preferences", {}).get("identity")
        values['sector'] = self.session.get("sector", {})
        values['sector_id'] = self.session.get("sector_id", {})
        identity_item = self.render_custom(
            self.theme_cfg.get_template("components", 'identity'),
            values.copy()
        )
        if identity_item:
            values['user_menu_items'].append(identity_item)
        return template, values
