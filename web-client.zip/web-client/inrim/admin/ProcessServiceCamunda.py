# Copyright INRIM (https://www.inrim.eu)
# See LICENSE file for full licensing details.
import asyncio
import copy
import json
import logging

from libs.camundapy.camunda_api import CamundaApi

from core.ContentService import ContentService
from core.ProcessService import ProcessServiceBase

logger = logging.getLogger(__name__)

DEFAULT_SLEEP_MILLISECONDS = 20 / 1000
MAX_TRY = 5


class ProcessServiceCamundaBase(ProcessServiceBase):
    model = "camunda_process"

    @classmethod
    def create(cls, content_service: ContentService, process_model,
               process_name):
        self = ProcessServiceCamundaBase()
        self.init(content_service, process_model, process_name)
        return self

    def log_process_status(self):
        logger.info(f" process {self.process}")
        logger.info(f" form_data {self.form_data}")
        logger.info(f" process_instance {self.process_instance}")
        # logger.info(f" process_vars {self.process_vars}")
        logger.info(f" current_task {self.current_task}")
        logger.info(f" execution {self.execution}")
        logger.info(f" current_task_name {self.current_task_name}")

    async def load_config(self):
        await super().load_config()
        self.camunda = CamundaApi(self.cfg)

    def fail_action(cls, model, err, redirect_url="self"):
        return {
            "completato": True,
            "error": True,
            "msg": err,
            "model": model,
            "next_action": "redirect", "next_page": redirect_url
        }

    async def safe_load_history_process_instance(self, process_id):
        try:
            return await self.camunda.get_history_process_instance(process_id)
        except Exception as e:
            pass
        return {}

    async def load_process_instance(self, process_id):
        logger.info(f"process_id: {process_id}")
        self.process_instance = {}
        try:
            self.process_instance = await self.camunda.get_process_instance(
                process_id)
            self.process_vars = await self.camunda.get_all_process_instance_variables(
                process_id)
            self.process_in_progress = True
        except Exception as e:
            # logger.exception(e) 404
            self.process_in_progress = False
            await asyncio.sleep(DEFAULT_SLEEP_MILLISECONDS)
            logger.info(f"history process_id: {process_id} ")
            self.process_instance = await self.safe_load_history_process_instance(
                self.process_instance_id)
            if not self.process_instance:
                self.process_instance['id'] = self.process_instance_id
            self.process_instance['ended'] = True
            self.process_instance['history'] = True
            await asyncio.sleep(DEFAULT_SLEEP_MILLISECONDS)
            self.process_vars = await self.camunda.get_history_process_instance_variables(
                self.process_instance_id)
            # logger.info(f"history process_vars: {self.process_vars} ")

    async def load_process_tasks(self, process_id):
        self.process_tasks = await self.camunda.get_tasks(process_id)
        self.process_ext_tasks = await self.camunda.get_ext_tasks(process_id)

    async def load_ext_task(self, task_id):
        self.user_task = False
        try:
            task = await self.camunda.get_ext_task_id(task_id)
            self.current_task = task.copy()
            self.current_task_name = self.current_task.get('topic_name')
        except Exception as e:
            pass

    async def load_task_id(self, task_id):
        logger.info(f"task task_id: {task_id}")
        self.current_task = await self.camunda.get_task_id(task_id)
        if not self.current_task:
            await self.load_ext_task(task_id)
        else:
            self.user_task = True
            self.current_task_name = self.current_task['taskDefinitionKey']
        self.current_task_id = task_id

    async def load_execution(self, execution_id):
        try:
            self.execution = await self.camunda.get_execution(execution_id)
            self.execution_local_vars = await self.camunda.get_execution_local_vars(
                execution_id)
        except Exception as e:
            self.execution = {
                "id": execution_id,
                "ended": True
            }
            self.execution_local_vars['ended'] = True

    async def update_process_current_task(self, process_id, task_id=""):
        await self.load_process_tasks(process_id)
        if not task_id:
            self.current_task = self.process_tasks[0].copy() if len(
                self.process_tasks) > 0 else {}
            self.user_task = True
            self.current_task_name = self.current_task.get('taskDefinitionKey')
            if not self.current_task:
                self.current_task = self.process_ext_tasks[0].copy() if len(
                    self.process_ext_tasks) > 0 else {}
                if self.current_task:
                    self.current_task_name = self.current_task.get(
                        'topic_name')
                    self.user_task = False
            self.current_task_id = self.current_task.get("id")
        else:
            self.current_task_id = task_id
            await self.load_task_id(task_id)

    def update_vars(self, base_vars):
        pvars = {}
        pvars['current_session_token'] = self.gateway.token
        pvars['session_is_api'] = self.gateway.is_api
        pvars['session_uid'] = self.gateway.session.get("user", {}).get("uid",
                                                                        "")
        if self.form_data:
            model = self.form_data.get("data_model")
            pvars[model] = self.form_data.copy()
            pvars['model'] = model
        if pvars:
            base_vars.update(pvars)
        return base_vars.copy()

    async def update_instance_vars(self):
        logger.info(" update ")
        save_form = {
            "response_data": {},
            "response": {},
            "error": False
        }
        self.process_vars = self.update_vars(copy.deepcopy(self.process_vars))
        if self.form_data and self.update_data:
            save_form = await self.handle_save_update_form()
        return save_form

    async def handle_save_update_form(self):
        logger.info(f"save")
        form_error = False
        if self.form_data and self.form_data.get("process_id"):
            self.form_data['process_id'] = self.process_instance_id
        response_data, response, self.content_service = await self.gateway.post_data(
            self.form_data.copy(), ui_response=False)
        if "error" in response_data.get('status', ""):
            form_error = True
        logger.info(f"save error? :{form_error} ")
        return {
            "response_data": response_data,
            "response": response,
            "error": form_error
        }

    async def handle_complete_save_form(self, save_form):
        logger.info(f" complete update --> {self.update_data}")
        if save_form.get("response_data") and self.update_data:
            res = await self.content_service.form_post_complete_response(
                save_form['response_data'], save_form['response'])
            if save_form.get("error") is True:
                return res
            else:
                model = self.form_data.get("data_model")
                rec_name = save_form['response_data']['data'].get("rec_name")
                logger.info(
                    f" reload form data name:{self.form_data.get('data_model')}"
                    f" - {rec_name}"
                )
                self.process_vars[model] = await self.gateway.get_record_data(
                    model, rec_name)
                return False
        return False

    async def check_process_status(self, process_id="", task_id="", **kwargs):
        logger.info("check process status")
        return await self._check_process_status(
            process_id=process_id, task_id=task_id)

    async def _check_process_status(self, process_id="", task_id="", **kwargs):
        await self.status(process_id, task_id=task_id)
        logger.info(
            f"check process status: {process_id} run_and_forget {self.run_and_forget}")
        if self.run_and_forget:
            data_for_response = {}
            data_for_response['status'] = "success"
            data_for_response['model'] = self.form_data.get("data_model")
            data_for_response['message'] = f"Processo  {self.process_rec_name} Avviato"
            logger.info(data_for_response)
            return await self.content_service.form_post_complete_response(
                data_for_response, {})
        else:
            return await self.check_task()

    async def status(self, process_id, task_id=""):
        logger.info(f"status {process_id}")
        await self.load_process_instance(process_id)
        await self.update_process_current_task(process_id, task_id=task_id)
        if self.process_instance.get('ended') is False and not self.user_task:
            await self.load_execution(self.current_task.get("executionId"))

    async def check_task(self):
        logger.info(f" user_task {self.user_task}")
        if not self.user_task:
            if self.execution.get("ended") is False:
                await self.check_ext_task()
            else:
                await self.load_ext_task(self.current_task_id)
        return await self.handle_response()

    async def check_ext_task(self):
        logger.info("wait for external task")
        while self.execution.get("ended") is False and self.current_task.get(
                "error_message") is None:
            await asyncio.sleep(DEFAULT_SLEEP_MILLISECONDS)
            await self.load_ext_task(self.current_task_id)
            await self.load_execution(self.execution.get("id"))
        if self.process_in_progress:
            await self.status(self.process_instance_id)
        logger.info("external task done")

    async def start(self, **kwargs):
        logger.info("start")
        await super().start(**kwargs)
        self.form_data = kwargs.get("form_data", {})
        self.update_data = kwargs.get("update_data", False)
        self.run_and_forget = kwargs.get("run_and_forget", False)
        if self.model == self.process_model:
            self.process_vars = json.loads(
                self.process_data.get('variables', "{}"))
            var_res_form = await self.update_instance_vars()
            res_save = await self.handle_complete_save_form(var_res_form)
            if var_res_form.get("error") is True and res_save:
                return res_save
            if not self.process_instance_id:
                self.process = await self.camunda.start_process(
                    process_key=self.process_data['rec_name'],
                    business_key=self.process_data.get('business_key'),
                    tenant_id=self.process_data.get('tenant_id'),
                    variables=self.process_vars
                )
                self.process_instance_id = self.process.get("instance_id")

            # self.log_process_status()

        logger.info(self.process)

    async def complete(self, **kwargs):
        await super().complete(**kwargs)
        self.form_data = kwargs.get("form_data", {})
        self.update_data = kwargs.get("update_data", False)
        self.run_and_forget = kwargs.get("run_and_forget", False)
        if self.model == self.process_model:
            self.process_instance_id = self.form_data.get("process_id")
            await self.status(self.process_instance_id)
            var_res_form = await self.update_instance_vars()
            res_save = await self.handle_complete_save_form(var_res_form)
            if var_res_form.get("error") is True and res_save:
                return res_save
            self.process_vars['last_task'] = self.current_task_name
            return await self.handle_complete()
        return await self.handle_response(check_last_task=False)

    async def handle_complete(self):
        logger.info("complete_task")
        try:
            await self.camunda.complete_task(self.current_task_id,
                                             self.process_vars)
            return await self._next()
        except Exception as e:
            logger.exception(e)
            data_model = self.form_data.get("data_model")
            self.process_vars[self.current_task_name] = self.fail_action(
                data_model, "")
            await self.make_client_response()

    async def _next(self, process_id="", task_id=""):
        logger.info(f"process_id: {process_id}")
        if process_id:
            self.process_instance_id = process_id
        return await self._check_process_status(
            process_id=self.process_instance_id, task_id=task_id)

    async def next(self, process_id="", task_id="", **kwargs):
        await self.load_config()
        await self.check_process_status(process_id=process_id, task_id=task_id)

    async def cancel(self, process_id="", task_id="", **kwargs):
        await self.load_config()
        process = {}
        return process

    async def handle_response(self, check_last_task=True):
        logger.info("response")
        await self.load_process_instance(self.process_instance_id)
        if check_last_task:
            self.current_task_name = self.process_vars.get("last_task")

        # self.log_process_status()
        return await self.make_client_response()

    async def make_client_response(self):
        logger.info(self.current_task_name)
        current_ctx = self.process_vars.get(self.current_task_name, {})
        data_for_response = {}
        error = current_ctx.get('error', False)
        model = current_ctx.get("model")
        if current_ctx.get('close_process', ""):
            p_to_delete = current_ctx.get('close_process')
            logger.info(f"Process exit, cancel useless process {p_to_delete}")
            if await self.camunda.cancel_process(p_to_delete):
                logger.info(f"cancel process {p_to_delete} ok")
            else:
                logger.info(f"cancel process {p_to_delete} error")
        if error is True:
            data_for_response['status'] = "error"
            data_for_response['model'] = model
            data_for_response['message'] = current_ctx.get(
                'msg', f"Errore nel task {self.current_task_name}")
            return await self.content_service.form_post_complete_response(
                data_for_response, {})
        if current_ctx.get('next_action') and current_ctx[
            'next_action'] == "redirect":
            data_for_response['action'] = current_ctx.get('next_action')
            url = current_ctx.get('next_page')
            if url == "self":
                url = "#"
            data_for_response['url'] = url
            return await self.content_service.form_post_complete_response(
                data_for_response, {})

        return {"reload": True, "link": "#"}
