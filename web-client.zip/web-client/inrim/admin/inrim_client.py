import sys

import logging
import ujson
#from aiologger import Logger
from typing import Optional
from client_api import *

from fastapi.responses import HTMLResponse

logger = logging.getLogger(__name__)


@client_api.get("/select_identity", tags=["admin client"])
async def identity(
        request: Request,
        miframe: Optional[str] = ""

):
    gateway = Gateway.new(
        request=request, settings=get_settings(), templates=templates)
    content_service = await gateway.content_service_from_record(
        "select_identity", rec_name="")
    content_service.content['action_url'] = "/identity"
    res = await content_service.compute_form()
    return HTMLResponse(res)
