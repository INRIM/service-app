# Copyright INRIM (https://www.inrim.eu)
# See LICENSE file for full licensing details.
import os
import sys

from core.Gateway import GatewayBase
from fastapi import Request
import logging

logger = logging.getLogger(__name__)
basedir = os.path.abspath(os.path.dirname(__file__))


class GatewayInrim(GatewayBase):

    @classmethod
    def create(cls, request: Request, settings, templates):
        self = GatewayInrim()
        self.init(request, settings, templates)
        return self

    async def middleware_server_post_action(self, content_service, submitted_data) -> dict:
        logger.info("middleware post")
        content = await super().middleware_server_post_action(content_service, submitted_data)
        if "/identity" in self.request.url.path:
            self.session = await self.get_session()
            model = submitted_data.get("data_model")
            schema = await self.get_schema(model)
            content = {
                "content": {
                    "editable": True,
                    "model": model,
                    "schema": schema.copy(),
                    "data": {},
                }
            }
            return {'status': 'content', "data": content}
        return content

