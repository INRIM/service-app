# Copyright INRIM (https://www.inrim.eu)
# See LICENSE file for full licensing details.
import json
import os
import sys
import logging
from datetime import datetime, timedelta
from core.ImportService import ImportService

import logging

logger = logging.getLogger(__name__)


class InrimService(ImportService):

    @classmethod
    def create(cls, gateway, remote_data):
        self = InrimService()
        self.init(gateway, remote_data)
        return self

    async def update_tasks(self, task_name, caledar_data, status={"status": "done"}):
        self.taskNames = ['update_model_access']
        self.task_models = ["model_access"]
        exec_status = status.copy()
        if caledar_data and caledar_data.get("status", "error") == "success":
            calendar = caledar_data['calendar']
            task = caledar_data['task']
            if task['model'] in self.task_models:
                logger.info(task_name)
                exec_status = await getattr(
                    self, f"handle_{task['rec_name']}")(task_name, task.copy(), calendar.copy())
        response = await super().update_tasks(task_name, caledar_data, exec_status.copy())
        return response

    async def handle_update_model_access(self, task_name, task, calendar):
        logger.info(f" {task['model']} -> {calendar.get('task_record_name')}")
        res = await self.gateway.get_remote_object("/resource/data/model_access")
        model_access = res.get("content").get("data")[:]
        logger.info(f" Update  Model Access  {len(model_access)} items")
        for rec in model_access:
            res = await self.gateway.post_remote_object("/action/submit_model_access", data=rec.copy())
            if "error" in res.get("status", ""):
                logger.error(res)
        logger.info(f" Update Model Access Done")
        updates = []
        return {"status": "done", "updates": updates}.copy()
