import os
import sys
import ujson
from core.themes.ThemeConfig import ThemeConfigBase


class ThemeConfigInrim(ThemeConfigBase):

    @classmethod
    def create(cls, theme):
        self = ThemeConfigInrim()
        self.theme = theme
        self.init(theme)
        return self

    def get_form_component_map(self):
        data = super().get_form_component_map()  # component_config_map.json
        local_path = f"{self.local_path}/inrim/admin/themes/italia/components_config"
        custom_builder_object_file = f"{local_path}/component_config_map.json"
        with open(custom_builder_object_file) as f:
            local_data = ujson.load(f)
        res = {**data, **local_data}
        return res.copy()

    def get_custom_builder_oject(self):
        local_path = f"{self.local_path}/inrim/admin/themes/italia/components_config"
        custom_builder_object_file = f"{local_path}/custom_builder_object.json"
        with open(custom_builder_object_file) as f:
            data = ujson.load(f)
        return data

