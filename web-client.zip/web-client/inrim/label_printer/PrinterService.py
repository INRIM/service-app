# Copyright INRIM (https://www.inrim.eu)
# See LICENSE file for full licensing details.
import logging
from datetime import datetime, timedelta
from inrim.admin.InrimService import InrimService

logger = logging.getLogger(__name__)


class PrinterService(InrimService):

    @classmethod
    def create(cls, gateway, remote_data):
        self = PrinterService()
        self.init(gateway, remote_data)
        return self

    async def update_tasks(self, task_name, caledar_data, status={"status": "done"}):
        self.taskNames = ['print_label_task', 'print_label_status_task']
        self.task_models = ["label_printer_queue", "label_printer"]

        self.views = {
            "label_printer": "view_printer_details",
            "label_printer_queue": "view_print_queue"
        }
        exec_status = status.copy()
        if caledar_data and caledar_data.get("status", "error") == "success":
            calendar = caledar_data['calendar']
            task = caledar_data['task']
            if task['model'] in self.task_models:
                logger.info(task['rec_name'])
                exec_status = await getattr(
                    self, f"handle_{task['rec_name']}")(task_name, task.copy(), calendar.copy())
                logger.info(exec_status)
        response = await super().update_tasks(task_name, caledar_data, exec_status.copy())
        return response

    async def handle_print_label_status_task(self, task_name, task, calendar):
        logger.info(f"execute calendar task name {task_name}")
        res = await self.gateway.get_remote_object(f"/db_view/view_printer_details")
        list_printers = res.get("content", {}).get("data", {})[:]
        model = "label_printer"
        updates = []
        for printer in list_printers:
            rec_name = printer['rec_name']
            stato = "spenta"
            code = ""
            url = f"{printer['urlStampante']}/status"
            try:
                rem_req = await self.gateway.get_remote_request(url)
                if not rem_req.get('printer_power_off') and rem_req.get("did_print"):
                    stato = "accesa"
                    stato_v = "Accesa"
                    code = rem_req.get("printer_name")
                elif rem_req.get('printer_power_off'):
                    stato = "spenta"
                    stato_v = "Spenta"
                else:
                    stato = "errore"
                    stato_v = "Errore"
            except Exception as e:
                logger.warning(f" Errore connessione stampante {printer['rec_name']} - {e}")
                stato = "errore"
                stato_v = "Errore"

            updates.append(
                {"model": model, "rec_name": rec_name, "fields": [
                    {"name": "stato", "value": stato, "data_value": stato_v},
                    {"name": "code_name", "value": code}
                ]}
            )
        return {"status": "done", "updates": updates}.copy()

    async def handle_print_label_task(self, task_name, task, calendar):
        task_record_name = calendar.get('task_record_name', "")
        updates = []
        gstato = "done"
        res = await self.gateway.get_remote_object(
            f"/db_view/view_print_queue", params={
                "domain": {"rec_name": task_record_name}
            })
        jobs = res.get("content", {}).get("data", {})[:]
        model = "label_printer_queue"
        logger.info(f" printer todo {len(jobs)} jobs")

        def get_printer(printer_name, printers_list):
            for printer_item in printers_list:
                if printer_item.get("rec_name") == printer_name:
                    return printer_item.copy()

        for job in jobs:
            rec_name = job['rec_name']
            printer = get_printer(job['model'], job['printer_details'])
            pmodel = printer['printer_type_docs'][0]['model']
            label_type = printer['tipoRotolo']
            datas = job['data'].split(",")
            url = f"{printer['urlStampante']}/print_label"
            body = {
                "data": datas[:],
                "model": pmodel,
                "label": label_type
            }
            active = True
            deleted = 0
            try:
                rem_req = await self.gateway.post_remote_request(url, data=body.copy())

                if "status" in rem_req:
                    stato = "error"
                    stato_v = "Errore"
                elif rem_req.get("outcome") == "printed":
                    stato = "done"
                    stato_v = "Fatto"
                    active = False
                    deleted = datetime.now().timestamp()
                else:
                    logger.info(f" Errore Stampa {job['rec_name']} - {e}")
                    logger.info(f" Errore Stampa Url Stampante {url}")
                    logger.info(f" Errore data {body}")
                    logger.info(f" rem_req {rem_req}")
                    stato = "error"
                    stato_v = "Errore"
            except Exception as e:
                logger.info(f" Errore Stampa {job['rec_name']} - {e}")
                logger.info(f" Errore Stampa Url Stampante {url}")
                logger.info(f" Errore data {body}")
                stato = "errore"
                stato_v = "Errore"

            updates.append(
                {"model": model, "rec_name": rec_name, "fields": [
                    {"name": "stato", "value": stato, "data_value": stato_v},
                    {"name": "active", "value": active}, {"name": "deleted", "value": deleted}
                ]}
            )
            updates.append(
                {"model": "calendar", "rec_name": calendar['rec_name'], "fields": [
                    {"name": "stato", "value": stato, "data_value": stato_v},
                    {"name": "active", "value": active}, {"name": "deleted", "value": deleted}
                ]}
            )
        return {"status": gstato, "updates": updates}.copy()
