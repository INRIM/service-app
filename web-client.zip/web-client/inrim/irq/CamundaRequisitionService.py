# Copyright INRIM (https://www.inrim.eu)
# See LICENSE file for full licensing details.

import asyncio
import logging
from datetime import datetime

from core.ContentService import ContentService
from core.Gateway import Gateway
from core.main.DateEngine import DateEngine
from fastapi.responses import RedirectResponse, JSONResponse
from libs.camundapy.camunda_api import CamundaApi

logger = logging.getLogger(__name__)
DEFAULT_SLEEP_MILLISECONDS = 20 / 1000
MAX_TRY = 5

states = {
    "accetta": "Approva",
    "rifiuta": "Respinge",
    "completa": "Completa"
}

AZIONI = {
    "accettaRifiuta": "Approvare o Respingere",
    "completa": "Completare",
}
DATA_STATES = {
    "nuova": "Inviata",
    "InCorso": "In Corso",
    "completa": "Completata",
    "rifiuta": "Respinta",
    "accetta": "Approvata",
}


class CamundaRequisitionService:

    def __init__(self, content_service: ContentService, process_model,
                 process_name):
        self.recipients = ""
        self.process_instance_id = None
        self.content_service: ContentService = content_service
        self.gateway: Gateway = content_service.gateway
        self.process_model = process_model
        self.process_rec_name = process_name
        self.user_task = False
        self.process_in_progress = False
        self.cfg = {}
        self.process_instance_id = ""
        self.current_task_id = ""
        self.current_ext_task_topic = ""
        self.process_instance = {}
        self.task_form = ""
        self.task_assignee = ""
        self.process_data = {}
        self.process = {}
        self.process_vars = {}
        self.execution = {}
        self.execution_local_vars = {}
        self.process_tasks = {}
        self.process_ext_tasks = {}
        self.current_task = {}
        self.current_task_name = ""
        self.current_task_vars = {}
        self.form_data = {}
        self.update_data = False
        self.dte = DateEngine(
            UI_DATETIME_MASK=self.gateway.local_settings.ui_datetime_mask,
            SERVER_DTTIME_MASK=self.gateway.local_settings.server_datetime_mask,
        )

    def log_process_status(self):
        logger.info(f" process {self.process}")
        logger.info(f" form_data {self.form_data}")
        logger.info(f" process_instance {self.process_instance}")
        # logger.info(f" process_vars {self.process_vars}")
        logger.info(f" current_task {self.current_task}")
        logger.info(f" execution {self.execution}")
        logger.info(f" current_task_name {self.current_task_name}")

    async def load_config(self):
        self.cfg = await self.gateway.get_param("camunda_irq")
        self.camunda = CamundaApi(self.cfg)

    @classmethod
    def fail_action(cls, model, err, redirect_url="self"):
        return {
            "completato": True,
            "error": True,
            "msg": err,
            "model": model,
            "next_action": "redirect", "next_page": redirect_url
        }

    async def safe_load_history_process_instance(self, process_id):
        try:
            return await self.camunda.get_history_process_instance(process_id)
        except Exception as e:
            pass
        return {}

    async def load_process_instance(self, process_id):
        logger.info(f"process_id: {process_id}")
        self.process_instance = {}
        try:
            self.process_instance = await self.camunda.get_process_instance(
                process_id)
            self.process_vars = await self.camunda.get_all_process_instance_variables(
                process_id)
            self.process_in_progress = True
        except Exception as e:
            logger.exception(e)
            self.process_in_progress = False
            await asyncio.sleep(DEFAULT_SLEEP_MILLISECONDS)
            logger.info(f"history process_id: {process_id} ")
            self.process_instance = await self.safe_load_history_process_instance(
                self.process_instance_id)
            if not self.process_instance:
                self.process_instance['id'] = self.process_instance_id
            self.process_instance['ended'] = True
            self.process_instance['history'] = True
            await asyncio.sleep(DEFAULT_SLEEP_MILLISECONDS)
            self.process_vars = await self.camunda.get_history_process_instance_variables(
                self.process_instance_id)
            # logger.info(f"history process_vars: {self.process_vars} ")

    async def load_process_tasks(self, process_id):
        self.process_tasks = await self.camunda.get_tasks(process_id)
        self.process_ext_tasks = await self.camunda.get_ext_tasks(process_id)

    async def load_ext_task(self, task_id):
        self.user_task = False
        try:
            task = await self.camunda.get_ext_task_id(task_id)
            self.current_task = task.copy()
            self.current_task_name = self.current_task.get('topic_name')
        except Exception as e:
            pass

    async def load_task_id(self, task_id):
        logger.info(f"task task_id: {task_id}")
        self.current_task = await self.camunda.get_task_id(task_id)
        if not self.current_task:
            await self.load_ext_task(task_id)
        else:
            self.user_task = True
            self.current_task_name = self.current_task['taskDefinitionKey']
        self.current_task_id = task_id

    async def load_execution(self, execution_id):
        try:
            self.execution = await self.camunda.get_execution(execution_id)
            self.execution_local_vars = await self.camunda.get_execution_local_vars(
                execution_id)
        except Exception as e:
            self.execution = {
                "id": execution_id,
                "ended": True
            }
            self.execution_local_vars['ended'] = True

    async def update_process_current_task(self, process_id, task_id=""):
        await self.load_process_tasks(process_id)
        if not task_id:
            self.current_task = self.process_tasks[0].copy() if len(
                self.process_tasks) > 0 else {}
            self.user_task = True
            self.current_task_name = self.current_task.get('taskDefinitionKey')
            self.task_form = self.current_task.get('formKey', "")
            if not self.current_task:
                self.current_task = self.process_ext_tasks[0].copy() if len(
                    self.process_ext_tasks) > 0 else {}
                if self.current_task:
                    self.current_task_name = self.current_task.get(
                        'topic_name')
                    self.user_task = False
            self.current_task_id = self.current_task.get("id")
        else:
            self.current_task_id = task_id
            await self.load_task_id(task_id)

    def eval_states_info(self, choice):
        tipoAzione = self.process_vars['tipoAzione']
        if states.get(choice) and AZIONI.get(tipoAzione):
            return states.get(choice)
        else:
            return self.process_vars.get('labelAzione')

    def update_vars(self, choice=None):
        pvars = {}
        # user = self.gateway.session.get("user", {})
        # pvars['user'] = user
        user = self.gateway.session.get("user", {})
        self.process_vars['last_choice'] = choice or ""
        self.process_vars['current_session_token'] = self.gateway.token
        if choice:
            choice_info = self.eval_states_info(choice)
            dt = self.dte.server_datetime_to_ui_datetime_str(
                datetime.now().isoformat())
            self.process_vars[
                "choices"] = (f"{pvars.get('choices', '')} \n "
                              f" il {dt} - {user.get('full_name')}  {choice_info}")

    async def update_instance_vars(self, choice=""):
        logger.info(" update ")
        save_form = {
            "response_data": {},
            "response": {},
            "error": False
        }
        self.update_vars(choice=choice)
        if self.form_data and self.update_data:
            save_form = await self.handle_save_update_form()
        return save_form

    async def handle_save_update_form(self):
        logger.info(f"save")
        form_error = False
        if self.form_data and self.form_data.get("process_id"):
            self.form_data['process_id'] = self.process_instance_id
        response_data, response, self.content_service = await self.gateway.post_data(
            self.form_data.copy(), ui_response=False)
        if "error" in response_data.get('status', ""):
            form_error = True
        logger.info(f"save error? :{form_error} ")
        return {
            "response_data": response_data,
            "response": response,
            "error": form_error
        }

    async def handle_complete_save_form(self, save_form):
        logger.info(f" complete update --> {self.update_data}")
        if save_form.get("response_data") and self.update_data:
            res = await self.content_service.form_post_complete_response(
                save_form['response_data'], save_form['response'])
            if save_form.get("error") is True:
                return res
            else:
                model = self.form_data.get("data_model")
                rec_name = save_form['response_data']['data'].get("rec_name")
                logger.info(
                    f" reload form data name:{self.form_data.get('data_model')}"
                    f" - {rec_name}"
                )
                self.process_vars[model] = await self.gateway.get_record_data(
                    model, rec_name)
                return False
        return False

    async def status(self, process_id, task_id=""):
        logger.info(f"status {process_id}")
        await self.load_process_instance(process_id)
        await self.update_process_current_task(process_id, task_id=task_id)
        await self.check_task()

    async def check_task(self):
        logger.info(f" check_ext_task {self.user_task}")
        if not self.user_task:
            if self.execution.get("ended") is False:
                await self._check_ext_task()
            else:
                await self.load_ext_task(self.current_task_id)

    async def _check_ext_task(self):
        logger.info("wait for external task")
        while self.execution.get("ended") is False and self.current_task.get(
                "error_message") is None:
            await asyncio.sleep(DEFAULT_SLEEP_MILLISECONDS)
            await self.load_ext_task(self.current_task_id)
            await self.load_execution(self.execution.get("id"))
        if self.process_in_progress:
            await self.status(self.process_instance_id)
        logger.info("external task done")

    async def _next(self, process_id="", task_id=""):
        logger.info(f"process_id: {process_id}")
        if process_id:
            self.process_instance_id = process_id
        return await self._check_process_status(
            process_id=self.process_instance_id, task_id=task_id)

    async def _check_process_status(self, process_id="", task_id="", **kwargs):
        await self.status(process_id, task_id=task_id)

    async def check_process_status(self, process_id="", task_id="", **kwargs):
        logger.info("check process status")
        if process_id:
            self.process_instance_id = process_id
        return await self._check_process_status(
            process_id=self.process_instance_id, task_id=task_id)

    async def ext_task_client_response(self):
        current_ctx = self.process_vars.get(self.current_task_name, {})
        data_for_response = {}
        error = current_ctx.get('error', False)
        model = current_ctx.get("model")
        if current_ctx.get('close_process', ""):
            p_to_delete = current_ctx.get('close_process')
            logger.info(f"Process exit, cancel useless process {p_to_delete}")
            if await self.camunda.cancel_process(p_to_delete):
                logger.info(f"cancel process {p_to_delete} ok")
            else:
                logger.info(f"cancel process {p_to_delete} error")
        if error is True:
            data_for_response['status'] = "error"
            data_for_response['model'] = model
            data_for_response['message'] = current_ctx.get(
                'msg', f"Errore nel task {self.current_task_name}")
            return await self.content_service.form_post_complete_response(
                data_for_response, {})
        if current_ctx.get('next_action'):
            if current_ctx['next_action'] == "redirect":
                data_for_response['action'] = current_ctx.get('next_action')
                url = current_ctx.get('next_page')
                if url == "self":
                    url = "#"
                data_for_response['url'] = url
                return await self.content_service.form_post_complete_response(
                    data_for_response, {})

        return {"reload": True, "link": "#"}

    async def user_task_client_response(self, new_process=False):
        data_for_response = {}
        if new_process:
            url = f"/action/new_{self.task_form}?process_id={self.process_instance_id}"
        else:
            url = f"/action/list_request_todo"
        data_for_response['action'] = "redirect"
        data_for_response['url'] = url
        return await self.content_service.form_post_complete_response(
            data_for_response, {})

    async def make_client_response(self, new_process=False):
        logger.info(self.current_task_name)
        if self.user_task:
            return await self.user_task_client_response(
                new_process=new_process)
        else:
            return await self.ext_task_client_response()

    async def handle_response(self, new_process=False, check_last_task=True):
        logger.info("response")
        if check_last_task:
            self.current_task_name = self.process_vars.get("last_task")
        return await self.make_client_response(new_process=new_process)

    async def start(self, **kwargs):
        logger.info("start")
        await self.load_config()
        self.form_data = kwargs.get("form_data", {})
        logger.info(f"process: {self.form_data['rec_name']}")
        self.process = await self.camunda.start_process(
            process_key=self.form_data['rec_name'],
            business_key=self.form_data.get('business_key', ""),
            tenant_id=self.form_data.get('tenant_id', ""),
            variables={
                "user": self.gateway.session.get("user", {}),
                "requisition": self.form_data.get('name'),
                "current_session_token": self.gateway.token,
                "applicant": self.form_data.get("richiedente", ""),
                "groupAssignee": "",
                "req_owner": self.gateway.session.get(
                    "user", {}).get("uid", ""),
                "last_choice": "",
                "choices": "",
                "form_data": {},
                "error": False
            }
        )
        self.process_instance_id = self.process.get("instance_id")
        logger.info(self.process)
        await self.check_process_status()
        return await self.handle_response(new_process=True)

    async def make_err_resp(self, err_msg):
        data_for_response = {}
        data_for_response['status'] = "error"
        data_for_response['model'] = self.form_data.get("data_model", "")
        data_for_response['message'] = err_msg
        return await self.content_service.form_post_complete_response(
            data_for_response, {})

    def user_allowed(self):
        user = self.gateway.session.get("user", {})
        user_session_uid = user.get("uid", "")
        user_session_div_code = user.get("divisione_code", "")
        if self.process_vars.get('assignee', ""):
            if user_session_uid == self.process_vars.get('assignee', ""):
                return True
        elif self.process_vars.get('groupAssignee', ""):
            if user_session_div_code == self.process_vars.get('groupAssignee'):
                return True
        return False

    def eval_label(self, local_dataset, var_name, stato):
        tipoAzione = self.process_vars['tipoAzione']
        res = "Non definita"
        # if stato != "completata":
        if local_dataset.get(tipoAzione):
            res = local_dataset.get(tipoAzione)
        else:
            res = self.process_vars.get(var_name, "Non definita")
        self.form_data[var_name] = res

    async def update_data_form(self, choice):
        url = f"/action/submit_{self.form_data['src_model']}/{str(self.form_data['src_record'])}"
        data = self.process_vars['form_data'].copy()
        data['stato'] = choice
        data['data_value']['stato'] = DATA_STATES.get(choice, "")
        return await self.gateway.post_remote_object(url, data=data)

    async def after_action_update(self, stato, choice):
        await self.camunda.complete_task(
            self.current_task_id, self.process_vars)
        await self.status(self.process_instance_id)
        self.form_data['assignee'] = self.process_vars.get('assignee', "")
        self.form_data['tipoAzione'] = self.process_vars['tipoAzione']
        self.form_data['lock'] = self.process_vars.get('lock')
        self.form_data['export'] = self.process_vars.get('export')
        self.eval_label(AZIONI, 'labelAzioni', stato)
        self.eval_label(states, 'labelAzione', stato)
        self.form_data['groupAssignee'] = self.process_vars.get(
            'groupAssignee', "")
        old = self.form_data.get('storicoAzioni', "")
        if old:
            self.form_data[
                'storicoAzioni'] = f"{old} <br/> {self.process_vars['choices']}"
        else:
            self.form_data['storicoAzioni'] = self.process_vars['choices']
        self.form_data['stato'] = stato
        if stato == "completata":
            self.form_data['data_fine_richiesta'] = datetime.now().isoformat()
        var_res_form = await self.handle_save_update_form()
        if var_res_form and var_res_form.get("error") is True:
            return var_res_form
        upd_data_form = await self.update_data_form(choice)
        if upd_data_form and upd_data_form.get("error"):
            return upd_data_form
        return await self.handle_response()

    async def subscribe(self, **kwargs):
        await self.load_config()
        self.form_data = kwargs.get("form_data", {})
        self.process_instance_id = self.form_data.get("process_id")

    async def delete_data_form(self):
        url = f"/action/delete_{self.form_data['src_model']}/{str(self.form_data['src_record'])}"
        return await self.gateway.delete_remote_object(url)

    async def delete_richiesta(self):
        url = f"/action/delete_richiesta/{str(self.form_data['rec_name'])}"
        return await self.gateway.delete_remote_object(url)

    async def cancel(self, **kwargs) -> RedirectResponse:
        self.form_data = kwargs.get("form_data", {})
        await self.load_config()
        self.process_instance_id = self.form_data.get("process_id")
        await self.status(self.process_instance_id)
        if 'lock' not in self.form_data or self.form_data.get('lock') is False:
            await self.delete_data_form()
            await self.delete_richiesta()
            await self.camunda.cancel_process(self.process_instance_id)
            return JSONResponse(
                {"action": "redirect", "link": "/", "reload": True,
                 "status": "ok"})
        else:
            return await self.content_service.form_post_complete_response(
                {"status": "error",
                 "model": "richiesta",
                 "message": "La richiesta non puo essere annnullata"}, {})

    async def complete(self, **kwargs):
        await self.load_config()
        self.form_data = kwargs.get("form_data", {})
        self.update_data = True
        self.process_instance_id = self.form_data.get("process_id")
        await self.status(self.process_instance_id)
        if not self.user_allowed():
            return await self.make_err_resp("Operazione non consentita")
        var_res_form = await self.update_instance_vars(choice="completa")
        res_save = await self.handle_complete_save_form(var_res_form)
        if var_res_form.get("error") is True and res_save:
            return res_save
        return await self.after_action_update(
            stato="completata", choice="completa")

    async def approve(self, **kwargs):
        await self.load_config()
        self.form_data = kwargs.get("form_data", {})
        # self.update_data = True
        self.process_instance_id = self.form_data.get("process_id")
        await self.status(self.process_instance_id)
        if not self.user_allowed():
            return await self.make_err_resp("Operazione non consentita")
        var_res_form = await self.update_instance_vars(choice="accetta")
        res_save = await self.handle_complete_save_form(var_res_form)
        if var_res_form.get("error") is True and res_save:
            return res_save
        return await self.after_action_update(
            stato="InCorso", choice="accetta")

    async def reject(self, **kwargs):
        await self.load_config()
        self.form_data = kwargs.get("form_data", {})
        self.update_data = True
        self.process_instance_id = self.form_data.get("process_id")
        await self.status(self.process_instance_id)
        if not self.user_allowed():
            return await self.make_err_resp("Operazione non consentita")
        var_res_form = await self.update_instance_vars(choice="rifiuta")
        res_save = await self.handle_complete_save_form(var_res_form)
        if var_res_form.get("error") is True and res_save:
            return res_save
        return await self.after_action_update(
            stato="completata", choice="rifiuta")
