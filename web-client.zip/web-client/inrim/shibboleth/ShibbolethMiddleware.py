import sys

# sys.path.append("..")

import logging
import ujson
import uuid
import time as time_
from core.Interceptor import InterceptorBase
from fastapi.responses import RedirectResponse, JSONResponse

logger = logging.getLogger(__name__)

SHIBBOLETH_HEADERS_KEY = "x-remote-user"


class InterceptorSbhibboleth(InterceptorBase):

    @classmethod
    def create(cls):
        self = InterceptorSbhibboleth()
        return self

    async def before_request(self, request):
        self.idm = str(uuid.uuid4())
        if not "/polling/calendar_tasks" in request.url.path and not request.url.path.startswith('/static'):
            logger.info(
                f"start request path={request.url.path}, rid={self.idm}, remote_req_id={request.headers.get('req_id')}")
            self.start_time = time_.time()
        request.scope['security_headers'] = {}
        # if SHIBBOLETH_HEADERS_KEY not in request.headers:
        request.scope['security_headers'].update(
            {SHIBBOLETH_HEADERS_KEY: request.headers.get(SHIBBOLETH_HEADERS_KEY, "")})

    async def before_response(self, request, response):
        if not "/polling/calendar_tasks" in request.url.path and not request.url.path.startswith('/static'):
            process_time = (time_.time() - self.start_time) * 1000
            formatted_process_time = '{0:.2f}'.format(process_time)
            logger.info(
                f"completed_in={formatted_process_time}ms status_code={response.status_code}, rid={self.idm}"
                f"remote_req_id={response.headers.get('req_id')}"
            )
        if response.status_code == 404:
            response = RedirectResponse("/")

        if SHIBBOLETH_HEADERS_KEY not in response.headers:
            response.headers[SHIBBOLETH_HEADERS_KEY] = request.headers.get(SHIBBOLETH_HEADERS_KEY, "")
        return response
