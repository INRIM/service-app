# Copyright INRIM (https://www.inrim.eu)
# See LICENSE file for full licensing details.
import logging
import os

from fastapi import Request
from inrim.admin.GatewayInrim import GatewayInrim

logger = logging.getLogger(__name__)
basedir = os.path.abspath(os.path.dirname(__file__))
SHIBBOLETH_HEADERS_KEY = "x-remote-user"

class GatewayShibbo(GatewayInrim):

    @classmethod
    def create(cls, request: Request, settings, templates):
        self = GatewayShibbo()
        self.init(request, settings, templates)
        return self

    async def get_session(self, params={}):
        logger.info("Shibbo get_session")
        data = await super().get_session(params=params)
        if SHIBBOLETH_HEADERS_KEY in self.headers:
            self.params['token'] = data.get('token')
            self.init_headers_and_token()
        return data.copy()
