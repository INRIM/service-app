import logging
import os

# from aiologger import Logger
from auth_api import *
from fastapi.responses import RedirectResponse
from inrim.cinecasso.CinecaSSO import CinecaSSO

logger = logging.getLogger(__name__)

SSO = os.environ.get("SSO")
CLIENT_SECRET = os.environ["CLIENT_SECRET"]
BASE_URI = os.environ["BASE_URI"]

sso = CinecaSSO(
    client_id=SSO,
    client_secret=CLIENT_SECRET,
    redirect_uri=f"{BASE_URI}/auth/callback",
    allow_insecure_http=True,
)


@auth_api.get("/login", tags=["admin client"])
async def identity(
        request: Request,
):
    """Initialize auth and redirect"""
    with sso:
        return await sso.get_login_redirect(
            params={"prompt": "consent", "access_type": "offline"})


@auth_api.get("/callback", tags=["google sso"])
async def auth_callback(request: Request):
    with sso:
        user = await sso.verify_and_process(request)
    if user:
        logger.info(user)
        gateway = Gateway.new(
            request=request, settings=get_settings(), templates=templates)
        result = await gateway.post_remote_object(
            "/auth/callback", data=user.dict())
        return RedirectResponse(f'{BASE_URI}{result["url"]}')
    else:
        return RedirectResponse("/login")
