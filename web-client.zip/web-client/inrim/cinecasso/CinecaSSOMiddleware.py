# sys.path.append("..")

import logging
import os
import time as time_
import uuid

from core.Gateway import Gateway
from core.Interceptor import InterceptorBase
from fastapi.responses import RedirectResponse
from settings import *

logger = logging.getLogger(__name__)

SSO = os.environ.get("SSO")


class InterceptorCinecaSSO(InterceptorBase):

    @classmethod
    def create(cls):
        self = InterceptorCinecaSSO()
        return self

    @classmethod
    async def cineca_auth(cls, request):
        return RedirectResponse("/auth/login")

    async def before_request(self, request):
        self.start_time = time_.time()
        self.idm = str(uuid.uuid4())
        logger.info(
            f"start request path={request.url.path}, SSO:{SSO}, rid={self.idm}, "
            f"remote_req_id={request.headers.get('req_id')}"
        )
        if SSO:
            gateway = Gateway.new(
                request=request, settings=get_settings(), templates=None)
            session = await gateway.get_session()
            authtoken = gateway.token
            if authtoken and session.get("is_public"):
                authtoken = None
            logger.info(f"check token: {authtoken}")
            if not authtoken and "/auth/callback" not in request.url.path:
                if "/auth/login" not in request.url.path:
                    request.scope['security_next_call'] = self.cineca_auth
            else:
                request.scope['security_next_call'] = None

        await super().before_request(request)
