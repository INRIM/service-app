from typing import TYPE_CHECKING, ClassVar, Optional
from fastapi_sso.sso.base import DiscoveryDocument, OpenID, SSOBase


class CinecaSSO(SSOBase):
    """Class providing login via Facebook OAuth."""

    provider = "cineca"
    base_url = "https://inrim.idp.cineca.it"
    scope: ClassVar = ["nickname"]

    async def get_discovery_document(self) -> DiscoveryDocument:
        """Get document containing handy urls."""
        return {
            "authorization_endpoint": f"{self.base_url}/idp/profile/oidc/authorize",
            "token_endpoint": f"{self.base_url}/idp/profile/oidc/token",
            "userinfo_endpoint": f"{self.base_url}/idp/profile/oidc/userinfo?fields=id,nickname,email,family_name,zoneinfo",
        }

    async def openid_from_response(self, response: dict, session: Optional["httpx.AsyncClient"] = None) -> OpenID:
        """Return OpenID from user information provided by Cineca."""

        return OpenID(
            email=response.get("email"),
            family_name=response.get("family_name"),
            uid=response.get("nickname"),
            zoneinfo=response.get("zoneinfo"),
            provider=self.provider,
            id=response.get("id")
        )