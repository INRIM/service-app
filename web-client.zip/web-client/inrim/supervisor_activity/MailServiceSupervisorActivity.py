# Copyright INRIM (https://www.inrim.eu)
# See LICENSE file for full licensing details.
import os
import sys

# sys.path.append("..")

from inrim.admin.InrimService import InrimService
import logging

logger = logging.getLogger(__name__)


class MailServiceSupervisorActivity(InrimService):
    @classmethod
    def create(cls, gateway, remote_data):
        self = MailServiceSupervisorActivity()
        self.init(gateway, remote_data)
        return self

    async def send_email(self, form_data, tmp_name=""):
        logger.info(form_data)
        if form_data.get("notify_owner") and not form_data.get("todo"):
            logger.info("send --> Activity")
            await super().send_email(form_data, tmp_name=tmp_name)
