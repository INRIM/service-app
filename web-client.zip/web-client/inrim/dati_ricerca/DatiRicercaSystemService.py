# Copyright INRIM (https://www.inrim.eu)
# See LICENSE file for full licensing details.
import os
import sys

from inrim.supervisor_activity.SupervisorActivitySystemService import SupervisorActivitySystemService
import logging

logger = logging.getLogger(__name__)
basedir = os.path.abspath(os.path.dirname(__file__))


class DatiRicercaSystemService(SupervisorActivitySystemService):
    @classmethod
    def create(cls, settings, templates):
        self = DatiRicercaSystemService()
        self.init(settings, templates)
        return self

    async def check_and_init_service(self):
        logger.info(f"check_and_init_service")
        await super().check_and_init_service()
        await self.compute_check_and_init_service(basedir)
